#ifndef _AES_H_
#define _AES_H_

#include <stdint.h>
#include <stddef.h>

// 只启用ECB和CTR模式
#define ECB 1
#define CTR 1

#define AES128 1        // 只使用AES-128
#define AES_BLOCKLEN 16 // AES块长度（128位）
#define AES_KEYLEN 16   // AES-128密钥长度
#define AES_keyExpSize 176  // AES-128密钥扩展大小

struct AES_ctx
{
  uint8_t RoundKey[AES_keyExpSize];
#if (CTR == 1)
  uint8_t Iv[AES_BLOCKLEN];
#endif
};

void AES_init_ctx(struct AES_ctx* ctx, const uint8_t* key);
#if (CTR == 1)
void AES_init_ctx_iv(struct AES_ctx* ctx, const uint8_t* key, const uint8_t* iv);
void AES_ctx_set_iv(struct AES_ctx* ctx, const uint8_t* iv);
#endif

#if (ECB == 1)
void AES_ECB_encrypt(const struct AES_ctx* ctx, uint8_t* buf);
void AES_ECB_decrypt(const struct AES_ctx* ctx, uint8_t* buf);
#endif

#if (CTR == 1)
void AES_CTR_xcrypt_buffer(struct AES_ctx* ctx, uint8_t* buf, size_t length);
#endif

#endif // _AES_H_
