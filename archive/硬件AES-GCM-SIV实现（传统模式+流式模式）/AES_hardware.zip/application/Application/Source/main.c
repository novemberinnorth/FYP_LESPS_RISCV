#include <main.h>
#include "bsp.h"
#include "cm32m4xxr_aes.h"
#include "cm32m4xxr_algo_common.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

// 宏定义
#define CHUNK_SIZE 1024
#define AES_BLOCK_SIZE 16
#define GCM_SIV_TAG_SIZE 16
#define B64_BUFFER_SIZE 2100
#define MAX_FILE_SIZE (100 * 1024 * 1024)  // 100MB限制
#define STREAMING_MODE_MARKER 0xFFFFFFFF   // 流式模式标记

// 调试级别控制
#define DEBUG_LEVEL 1

#if DEBUG_LEVEL >= 1
#define DBG_PRINT(...) printf(__VA_ARGS__)
#else
#define DBG_PRINT(...)
#endif

#if DEBUG_LEVEL >= 2
#define DBG_VERBOSE(...) printf(__VA_ARGS__)
#else
#define DBG_VERBOSE(...)
#endif

// 操作模式
typedef enum {
    OP_ENCRYPT,
    OP_DECRYPT
} operation_mode_t;

// GCM-SIV会话状态
typedef struct {
    operation_mode_t mode;
    uint8_t base_nonce[16];     // 基础Nonce
    uint32_t total_processed;
    uint32_t total_file_size;
    uint8_t is_last_chunk;
    uint32_t chunk_index;       // 块索引
    uint8_t is_streaming;       // 是否为流式模式
    uint8_t streaming_active;   // 流式模式是否激活
} gcm_siv_session_t;

USART_InitType USART_InitStructure;

// 全局缓冲区
static uint8_t input_buffer[CHUNK_SIZE + 64];
static uint8_t output_buffer[CHUNK_SIZE + 64];

// 硬件AES包装函数
void aes_ecb_encrypt(uint8_t *output, uint8_t *input, uint8_t *key);
void aes_ctr_crypt(uint8_t *output, uint8_t *input, uint32_t input_len,
                  uint8_t *counter, uint8_t *key);

void RCC_Configuration(void) {
    GPIO_APBxClkCmd(USARTx_GPIO_CLK | RCC_APB2_PERIPH_AFIO, ENABLE);
    USART_APBxClkCmd(USARTx_CLK, ENABLE);
}

void GPIO_Configuration(void) {
    GPIO_InitType GPIO_InitStructure;
    GPIO_ConfigPinRemap(GPIO_RMP3_UART4, ENABLE);

    GPIO_InitStructure.Pin        = USARTx_TxPin;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_Init(USARTx_GPIO, &GPIO_InitStructure);

    GPIO_InitStructure.Pin       = USARTx_RxPin;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(USARTx_GPIO, &GPIO_InitStructure);
}

int _put_char(int ch) {
    USART_SendData(USARTx, (uint8_t)ch);
    while (USART_GetFlagStatus(USARTx, USART_FLAG_TXDE) == RESET);
    return ch;
}

int _get_char(void) {
    uint32_t timeout = 5000000;
    while (USART_GetFlagStatus(USARTx, USART_FLAG_RXDNE) == RESET) {
        timeout--;
        if (timeout == 0) return -1;
    }
    int ch = (int)USART_ReceiveData(USARTx);
    return ch;
}

// 系统滴答计时器
volatile uint32_t system_tick = 0;

void SysTick_Handler(void) {
    system_tick++;
}

uint32_t get_current_time(void) {
    return system_tick * 1000;
}

void init_systick(void) {
    SysTick_Config(SystemCoreClock / 1000);
}

void send_ack(void) {
    printf("ACK\n");
}

void send_error(const char* message) {
    printf("ERROR:%s\n", message);
}

void clear_receive_buffer(void) {
    DBG_VERBOSE("Clearing receive buffer...\n");
    uint32_t cleared_count = 0;
    while (USART_GetFlagStatus(USARTx, USART_FLAG_RXDNE) != RESET) {
        USART_ReceiveData(USARTx);
        cleared_count++;
    }
    DBG_VERBOSE("Cleared %lu bytes\n", cleared_count);
}

uint32_t read_exact_data(uint8_t *data, uint32_t exact_len, uint32_t timeout_ms) {
    uint32_t bytes_read = 0;
    uint32_t timeout = timeout_ms * 1000;
    uint32_t last_receive_time = get_current_time();
    uint32_t start_time = get_current_time();

    DBG_VERBOSE("Reading %d bytes\n", exact_len);

    while (bytes_read < exact_len) {
        if (USART_GetFlagStatus(USARTx, USART_FLAG_RXDNE) != RESET) {
            data[bytes_read] = USART_ReceiveData(USARTx);
            bytes_read++;
            last_receive_time = get_current_time();

            if (bytes_read % 100 == 0) {
                DBG_VERBOSE("Received %d/%d\n", bytes_read, exact_len);
            }
        } else {
            uint32_t current_time = get_current_time();
            if (current_time - last_receive_time > 500000) {
                DBG_PRINT("No data timeout: %d/%d\n", bytes_read, exact_len);
                break;
            }
            if (current_time - start_time > timeout) {
                DBG_PRINT("Overall timeout: %d/%d\n", bytes_read, exact_len);
                break;
            }
        }
    }

    DBG_VERBOSE("Read complete: %d/%d\n", bytes_read, exact_len);
    return bytes_read;
}

// 在适当的地方添加串口发送状态检查
void wait_for_tx_complete(void) {
    // 等待发送缓冲区为空
    while (USART_GetFlagStatus(USARTx, USART_FLAG_TXDE) == RESET) {
        // 短暂等待
        for(volatile int i = 0; i < 100; i++);
    }
}

void send_encrypted_data_base64(uint8_t *data, uint32_t len) {
    const char base64_chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    uint32_t b64_len = 4 * ((len + 2) / 3);

    // 使用动态分配或确保缓冲区不被覆盖
    // 这里我们使用更大的静态缓冲区并添加保护
    static char b64_buffer[B64_BUFFER_SIZE];
    static uint8_t buffer_lock = 0;  // 简单的缓冲区锁

    // 等待前一次发送完成
    while (buffer_lock) {
        // 短暂等待
        for(volatile int i = 0; i < 1000; i++);
    }

    buffer_lock = 1;

    // 输入验证
    if (len == 0 || len > (CHUNK_SIZE + 32)) {
        printf("ERROR: Invalid data length for Base64: %lu\n", len);
        buffer_lock = 0;
        return;
    }

    if (b64_len >= B64_BUFFER_SIZE) {
        printf("ERROR: Base64 buffer too small: needed %lu, have %lu\n",
               b64_len, B64_BUFFER_SIZE);
        buffer_lock = 0;
        return;
    }

    DBG_VERBOSE("Base64 encoding: input_len=%lu, b64_len=%lu\n", len, b64_len);

    // Base64编码
    int i, j;
    uint32_t triple;

    for (i = 0, j = 0; i < len; i += 3, j += 4) {
        triple = (data[i] << 16);
        if (i + 1 < len) triple |= (data[i + 1] << 8);
        if (i + 2 < len) triple |= data[i + 2];

        b64_buffer[j]   = base64_chars[(triple >> 18) & 0x3F];
        b64_buffer[j+1] = base64_chars[(triple >> 12) & 0x3F];
        b64_buffer[j+2] = (i + 1 < len) ? base64_chars[(triple >> 6) & 0x3F] : '=';
        b64_buffer[j+3] = (i + 2 < len) ? base64_chars[triple & 0x3F] : '=';
    }
    b64_buffer[j] = '\0';

    // 验证Base64字符串完整性
    if (strlen(b64_buffer) != b64_len) {
        printf("ERROR: Base64 length mismatch: expected %lu, got %lu\n",
               b64_len, strlen(b64_buffer));
        buffer_lock = 0;
        return;
    }

    // 立即发送并等待发送完成
    printf("B64:%s\n", b64_buffer);
    wait_for_tx_complete();  // 等待发送完成

    // 刷新输出缓冲区，确保数据完全发送
    // 注意：在嵌入式系统中，printf通常立即发送，但为了安全还是等待
    for(volatile int i = 0; i < 5000; i++);  // 短暂延迟

    DBG_VERBOSE("Base64 sent: %lu chars\n", strlen(b64_buffer));

    buffer_lock = 0;  // 释放缓冲区
}

// ==================== GCM-SIV 实现 ====================

// GF(2^128)乘法
void gfmul(const uint64_t *a, const uint64_t *b, uint64_t *res) {
    uint64_t tmp1[2], tmp2[2], tmp3[2], tmp4[2];
    uint64_t XMMMASK[2] = {0x1, 0xc200000000000000};

    // 简化的GF乘法实现
    // 这里使用查表法或软件实现，可根据性能需求优化
    uint64_t v[2] = {b[0], b[1]};
    uint64_t z[2] = {0, 0};

    for (int i = 0; i < 128; i++) {
        if (a[i/64] & (1ULL << (i % 64))) {
            z[0] ^= v[0];
            z[1] ^= v[1];
        }

        int carry = v[1] & 1;
        v[1] = (v[1] >> 1) | (v[0] << 63);
        v[0] = v[0] >> 1;

        if (carry) {
            v[0] ^= XMMMASK[0];
            v[1] ^= XMMMASK[1];
        }
    }

    res[0] = z[0];
    res[1] = z[1];
}

/**
 * @brief POLYVAL更新函数
 */
void polyval_update(uint64_t polyval[2], const uint8_t hash_key[16],
                   const uint8_t *data, uint32_t len) {
    uint32_t blocks = len / 16;
    const uint64_t *data64 = (const uint64_t*)data;

    for (uint32_t i = 0; i < blocks; i++) {
        // XOR with current data block
        polyval[0] ^= data64[2*i];
        polyval[1] ^= data64[2*i+1];

        // Multiply by H in GF(2^128)
        gfmul(polyval, (const uint64_t*)hash_key, polyval);
    }

    // 处理不完整的最后一个块（如果有）
    uint32_t remaining = len % 16;
    if (remaining > 0) {
        uint8_t last_block[16] = {0};
        memcpy(last_block, data + blocks * 16, remaining);

        uint64_t *last_block64 = (uint64_t*)last_block;
        polyval[0] ^= last_block64[0];
        polyval[1] ^= last_block64[1];

        gfmul(polyval, (const uint64_t*)hash_key, polyval);
    }
}

// 硬件AES-ECB加密包装
void aes_ecb_encrypt(uint8_t *output, uint8_t *input, uint8_t *key) {
    AES_PARM AES_Parm = {0};

    AES_Parm.in = (uint32_t*)input;
    AES_Parm.out = (uint32_t*)output;
    AES_Parm.key = (uint32_t*)key;
    AES_Parm.iv = NULL;
    AES_Parm.inWordLen = 4; // 16 bytes = 4 words
    AES_Parm.keyWordLen = 4;
    AES_Parm.Mode = AES_ECB;
    AES_Parm.En_De = AES_ENC;

    if (AES_Init_OK == AES_Init(&AES_Parm)) {
        AES_Crypto(&AES_Parm);
        AES_Close();
    }
}

// 硬件AES-CTR加密/解密包装
void aes_ctr_crypt(uint8_t *output, uint8_t *input, uint32_t input_len,
                     uint8_t *counter, uint8_t *key) {
    AES_PARM AES_Parm = {0};

    AES_Parm.in = (uint32_t*)input;
    AES_Parm.out = (uint32_t*)output;
    AES_Parm.key = (uint32_t*)key;
    AES_Parm.iv = (uint32_t*)counter;        // 使用IV参数传递计数器
    AES_Parm.inWordLen = (input_len + 3) / 4; // 计算word长度(向上取整)
    AES_Parm.keyWordLen = 4;
    AES_Parm.Mode = AES_CTR;
    AES_Parm.En_De = AES_ENC;                // CTR模式加密解密相同

    if (AES_Init_OK == AES_Init(&AES_Parm)) {
        AES_Crypto(&AES_Parm);
        AES_Close();
    } else {
        // 错误处理
        DBG_PRINT("Hardware AES-CTR init failed\n");
    }
}

/**
 * @brief 更新Nonce（基于块索引的确定性策略）- 安全版本
 */
void update_nonce(uint8_t *nonce, const uint8_t *base_nonce, uint32_t chunk_index) {
    // 使用基础Nonce和块索引构建唯一Nonce
    memcpy(nonce, base_nonce, 12);  // 使用前12字节作为基础

    // 使用后4字节存储块索引（大端序），确保不会重复
    if (chunk_index > 0xFFFFFFFF) {
        DBG_PRINT("WARNING: Chunk index overflow: %lu\n", chunk_index);
        // 回绕处理
        chunk_index = chunk_index % 0xFFFFFFFF;
    }

    nonce[12] = (chunk_index >> 24) & 0xFF;
    nonce[13] = (chunk_index >> 16) & 0xFF;
    nonce[14] = (chunk_index >> 8) & 0xFF;
    nonce[15] = chunk_index & 0xFF;

    DBG_VERBOSE("Nonce for chunk %lu: ", chunk_index);
    for(int i=0; i<16; i++) DBG_VERBOSE("%02x", nonce[i]);
    DBG_VERBOSE("\n");
}

/**
 * @brief 单个块的GCM-SIV加密
 */
int gcm_siv_encrypt_single_chunk(uint8_t *ciphertext, uint8_t tag[16],
                                uint8_t key[16], uint8_t nonce[16],
                                uint8_t *plaintext, uint32_t plaintext_len) {

    // 派生密钥（基于Nonce）
    uint8_t hash_key[16], enc_key[16];
    uint32_t counter[4] = {0};
    uint8_t temp[16];

    memcpy(counter, nonce, 12);
    for (int i = 0; i < 4; i++) {
        counter[0] = i;
        aes_ecb_encrypt(temp, (uint8_t*)counter, key);

        if (i == 0) memcpy(hash_key, temp, 8);
        else if (i == 1) memcpy(hash_key + 8, temp, 8);
        else if (i == 2) memcpy(enc_key, temp, 8);
        else if (i == 3) memcpy(enc_key + 8, temp, 8);
    }

    // POLYVAL计算（仅这个块）
    uint64_t polyval[2] = {0};

    // 处理AAD（这里为空，可以添加块索引等作为AAD增强安全性）
    // polyval_update(polyval, hash_key, aad, aad_len);

    // 处理明文
    polyval_update(polyval, hash_key, plaintext, plaintext_len);

    // 添加长度块
    uint64_t len_block[2] = {0, (plaintext_len << 3)}; // AAD长度=0
    polyval[0] ^= len_block[0];
    polyval[1] ^= len_block[1];
    gfmul(polyval, (uint64_t*)hash_key, polyval);

    // XOR with nonce并生成标签
    polyval[0] ^= ((uint64_t*)nonce)[0];
    polyval[1] ^= ((uint64_t*)nonce)[1];
    ((uint8_t*)polyval)[15] &= 0x7F;

    uint8_t polyval_bytes[16];
    memcpy(polyval_bytes, polyval, 16);
    aes_ecb_encrypt(tag, polyval_bytes, enc_key);

    // CTR加密
    uint8_t counter_ctr[16];
    memcpy(counter_ctr, tag, 16);
    counter_ctr[15] |= 0x80;
    aes_ctr_crypt(ciphertext, plaintext, plaintext_len, counter_ctr, enc_key);

    return 0;
}

/**
 * @brief 单个块的GCM-SIV解密 - 增强版本
 */
int gcm_siv_decrypt_single_chunk(uint8_t *plaintext,
                                uint8_t key[16], uint8_t nonce[16],
                                uint8_t *ciphertext, uint32_t ciphertext_len,
                                uint8_t *expected_tag) {

    DBG_PRINT("GCM-SIV Decrypt: chunk_size=%u, nonce=", ciphertext_len);
    for(int i=0; i<16; i++) DBG_PRINT("%02x", nonce[i]);
    DBG_PRINT("\n");

    // 检查输入长度
    if (ciphertext_len == 0 || ciphertext_len > CHUNK_SIZE + 16) {
        DBG_PRINT("ERROR: Invalid ciphertext length: %u\n", ciphertext_len);
        return -1;
    }

    // 派生密钥（必须与加密时相同）
    uint8_t hash_key[16], enc_key[16];
    uint32_t counter[4] = {0};
    uint8_t temp[16];

    memcpy(counter, nonce, 12);
    for (int i = 0; i < 4; i++) {
        counter[0] = i;
        aes_ecb_encrypt(temp, (uint8_t*)counter, key);

        if (i == 0) memcpy(hash_key, temp, 8);
        else if (i == 1) memcpy(hash_key + 8, temp, 8);
        else if (i == 2) memcpy(enc_key, temp, 8);
        else if (i == 3) memcpy(enc_key + 8, temp, 8);
    }

    DBG_VERBOSE("Hash key: ");
    for(int i=0; i<16; i++) DBG_VERBOSE("%02x", hash_key[i]);
    DBG_VERBOSE("\nEnc key: ");
    for(int i=0; i<16; i++) DBG_VERBOSE("%02x", enc_key[i]);
    DBG_VERBOSE("\n");

    // CTR解密
    uint8_t counter_ctr[16];
    memcpy(counter_ctr, expected_tag, 16);
    counter_ctr[15] |= 0x80;

    DBG_VERBOSE("CTR counter: ");
    for(int i=0; i<16; i++) DBG_VERBOSE("%02x", counter_ctr[i]);
    DBG_VERBOSE("\n");

    aes_ctr_crypt(plaintext, ciphertext, ciphertext_len, counter_ctr, enc_key);

    // POLYVAL计算验证
    uint64_t polyval[2] = {0};

    // 处理解密后的明文
    polyval_update(polyval, hash_key, plaintext, ciphertext_len);

    // 添加长度块
    uint64_t len_block[2] = {0, (ciphertext_len << 3)};
    polyval[0] ^= len_block[0];
    polyval[1] ^= len_block[1];
    gfmul(polyval, (uint64_t*)hash_key, polyval);

    // XOR with nonce并生成标签
    polyval[0] ^= ((uint64_t*)nonce)[0];
    polyval[1] ^= ((uint64_t*)nonce)[1];
    ((uint8_t*)polyval)[15] &= 0x7F;

    uint8_t computed_tag[16];
    uint8_t polyval_bytes[16];
    memcpy(polyval_bytes, polyval, 16);
    aes_ecb_encrypt(computed_tag, polyval_bytes, enc_key);

    DBG_PRINT("Computed tag: ");
    for(int i=0; i<16; i++) DBG_PRINT("%02x", computed_tag[i]);
    DBG_PRINT("\nExpected tag: ");
    for(int i=0; i<16; i++) DBG_PRINT("%02x", expected_tag[i]);
    DBG_PRINT("\n");

    // 验证标签
    if (memcmp(computed_tag, expected_tag, 16) != 0) {
        DBG_PRINT("GCM-SIV tag verification failed for chunk\n");
        DBG_PRINT("POLYVAL state: %016llx%016llx\n", polyval[1], polyval[0]);
        return -1;
    }

    DBG_VERBOSE("GCM-SIV tag verification successful\n");
    return 0;
}

/**
 * @brief 处理文件块加解密 - 基于块索引的GCM-SIV版本
 */
int process_file_chunk_gcm_siv(operation_mode_t mode, uint8_t *input_data, uint32_t input_len,
                              uint8_t *output_data, uint32_t *output_len,
                              gcm_siv_session_t *session, uint8_t *key) {
    DBG_PRINT("Processing chunk %lu: mode=%s, input_len=%u, streaming=%d\n",
                 session->chunk_index, mode == OP_ENCRYPT ? "encrypt" : "decrypt",
                 input_len, session->is_streaming);

    uint8_t nonce[16];
    uint8_t tag[16];

    // 生成块Nonce
    update_nonce(nonce, session->base_nonce, session->chunk_index);

    DBG_VERBOSE("GCM-SIV Processing: mode=%s, len=%d, chunk_index=%lu\n",
               mode == OP_ENCRYPT ? "encrypt" : "decrypt", input_len, session->chunk_index);

    if (mode == OP_ENCRYPT) {
        // 加密这个块
        int result = gcm_siv_encrypt_single_chunk(output_data, tag, key, nonce,
                                                 input_data, input_len);
        if (result != 0) {
            DBG_PRINT("GCM-SIV encryption failed for chunk %lu\n", session->chunk_index);
            return -1;
        }

        // 将标签附加在密文后面
        memcpy(output_data + input_len, tag, 16);
        *output_len = input_len + 16;

        // 注意：现在不在这个函数内发送Base64数据，由调用者负责
        // 这样可以保持两种模式的一致性

    } else {
        // 解密模式：分离密文和标签
        if (input_len < 16) {
            DBG_PRINT("Invalid input length for decryption: %d\n", input_len);
            return -1;
        }

        uint32_t ciphertext_len = input_len - 16;
        uint8_t *ciphertext = input_data;
        uint8_t *received_tag = input_data + ciphertext_len;

        int result = gcm_siv_decrypt_single_chunk(output_data, key, nonce,
                                                 ciphertext, ciphertext_len, received_tag);
        if (result != 0) {
            DBG_PRINT("GCM-SIV decryption failed for chunk %lu\n", session->chunk_index);
            return -1;
        }

        *output_len = ciphertext_len;
    }

    // 递增块索引
    session->chunk_index++;
    session->total_processed += input_len;

    DBG_VERBOSE("Chunk processed: index=%lu, total=%lu bytes\n",
                session->chunk_index, session->total_processed);

    return 0;
}

// 传统模式数据处理函数
void process_traditional_data(gcm_siv_session_t *session, uint8_t *key) {
    uint32_t total_received = 0;
    uint32_t chunk_count = 0;
    uint32_t file_size = session->total_file_size;
    uint32_t num_chunks = 0;
    operation_mode_t mode = session->mode;

    if (mode == OP_DECRYPT) {
        // 计算加密后的块大小模式
        uint32_t remaining = file_size;
        num_chunks = 0;

        while (remaining > 0) {
            if (remaining > (CHUNK_SIZE + 16)) {
                remaining -= (CHUNK_SIZE + 16);
            } else {
                remaining = 0;
            }
            num_chunks++;
        }
        DBG_PRINT("GCM-SIV Decryption: calculated %lu chunks\n", num_chunks);
    }

    // 处理数据块
    while (total_received < file_size) {
        chunk_count++;
        uint32_t remaining = file_size - total_received;
        uint32_t chunk_size;

        // 关键：在解密模式下使用动态计算的加密块大小
        if (mode == OP_DECRYPT) {
            // 动态计算当前块的加密大小
            if (remaining >= (CHUNK_SIZE + 16)) {
                chunk_size = CHUNK_SIZE + 16;
            } else {
                chunk_size = remaining; // 最后一个块
            }
            DBG_VERBOSE("GCM-SIV Decryption chunk %lu: using encrypted size %lu\n",
                       chunk_count, chunk_size);
        } else {
            // 加密模式：使用正常的CHUNK_SIZE
            chunk_size = (remaining > CHUNK_SIZE) ? CHUNK_SIZE : remaining;
            DBG_VERBOSE("GCM-SIV Encryption chunk %lu: using normal size %lu\n",
                       chunk_count, chunk_size);
        }

        printf("WAIT_CHUNK:%d\n", chunk_size);

        uint32_t received_len = read_exact_data(input_buffer, chunk_size, 10000);

        if (received_len == chunk_size) {
            total_received += received_len;
            printf("CHUNK_RECEIVED:%d\n", received_len);
        } else {
            DBG_PRINT("Chunk receive failed: expected %d, got %d\n", chunk_size, received_len);
            DBG_PRINT("  Total received: %lu, File size: %lu\n", total_received, file_size);
            break;
        }

        // 检查是否是最后一个块
        session->is_last_chunk = (total_received >= file_size) ? 1 : 0;

        uint32_t output_len = 0;

        // 调用基于块索引的GCM-SIV处理函数
        int result = process_file_chunk_gcm_siv(mode, input_buffer, received_len,
                                               output_buffer, &output_len, session, key);

        if (result != 0) {
            DBG_PRINT("GCM-SIV processing failed for chunk %lu: result=%d\n",
                     chunk_count, result);
            printf("B64:\n");  // 发送空的Base64数据表示失败
            printf("CHUNK_PROCESSED:%d->%d\n", received_len, 0);

            // 如果是解密失败，立即退出
            if (mode == OP_DECRYPT) {
                DBG_PRINT("Decryption authentication failed, stopping\n");
                break;
            }
        } else {
            // 成功处理，发送加密/解密后的数据
            send_encrypted_data_base64(output_buffer, output_len);
            printf("CHUNK_PROCESSED:%d->%d\n", received_len, output_len);
        }

        int progress = (total_received * 100) / file_size;
        printf("PROGRESS:%d%%\n", progress);

        // 如果解密失败，提前退出
        if (mode == OP_DECRYPT && result != 0) {
            break;
        }
    }

    printf("STREAM_COMPLETE\n");
    printf("SUMMARY: received=%lu, processed=%lu, chunks=%lu\n",
           total_received, session->total_processed, chunk_count);

    if (total_received == file_size) {
        if (mode == OP_ENCRYPT || (mode == OP_DECRYPT && session->total_processed > 0)) {
            printf("SUCCESS: All data processed\n");
        } else {
            printf("WARNING: All data received but not fully processed\n");
        }
    } else {
        printf("WARNING: Incomplete: expected=%lu, received=%lu, processed=%lu\n",
               file_size, total_received, session->total_processed);
    }
}

// 流式模式数据处理函数
void process_streaming_data(gcm_siv_session_t *session, uint8_t *key) {
    uint32_t total_received = 0;
    uint32_t chunk_count = 0;
    uint8_t streaming_ended = 0;

    printf("READY_FOR_DATA\n");
    wait_for_tx_complete();

    // 流式模式处理循环
    while (!streaming_ended) {
        chunk_count++;
        session->chunk_index = chunk_count - 1;  // 从0开始

        // 关键修复：根据操作模式调整请求的块大小
        uint32_t requested_size;
        if (session->mode == OP_DECRYPT) {
            // 解密模式：需要接收密文+标签，所以块更大
            requested_size = CHUNK_SIZE + 16;  // 明文1024 + 16字节标签
            DBG_VERBOSE("Decrypt mode: requesting %lu bytes (CHUNK_SIZE + 16)\n", requested_size);
        } else {
            // 加密模式：只需要接收明文
            requested_size = CHUNK_SIZE;
            DBG_VERBOSE("Encrypt mode: requesting %lu bytes\n", requested_size);
        }

        printf("WAIT_CHUNK:%d\n", requested_size);
        wait_for_tx_complete();

        // 接收数据块（包含4字节头部）
        uint8_t chunk_header[4];
        uint32_t header_received = read_exact_data(chunk_header, 4, 10000);

        if (header_received != 4) {
            DBG_PRINT("Failed to receive chunk header\n");
            printf("ERROR:Chunk header receive failed\n");
            break;
        }

        // 解析块大小（大端序）
        uint32_t chunk_size = (chunk_header[0] << 24) | (chunk_header[1] << 16) |
                             (chunk_header[2] << 8) | chunk_header[3];

        // 检查是否为结束标记（块大小为0）
        if (chunk_size == 0) {
            printf("END_OF_STREAM\n");
            wait_for_tx_complete();
            streaming_ended = 1;
            session->streaming_active = 0;
            break;
        }

        // 检查块大小是否合理
        uint32_t max_expected_size = (session->mode == OP_DECRYPT) ?
                                     (CHUNK_SIZE + 16 + 64) : (CHUNK_SIZE + 64);

        if (chunk_size > max_expected_size) {
            DBG_PRINT("Invalid chunk size: %lu (max expected: %lu)\n", chunk_size, max_expected_size);
            printf("ERROR:Invalid chunk size\n");
            break;
        }

        // 接收实际数据
        uint32_t received_len = read_exact_data(input_buffer, chunk_size, 10000);

        if (received_len != chunk_size) {
            DBG_PRINT("Chunk receive failed: expected %lu, got %lu\n",
                     chunk_size, received_len);
            printf("ERROR:Chunk receive failed\n");
            break;
        }

        total_received += received_len;
        printf("CHUNK_RECEIVED:%d\n", received_len);
        wait_for_tx_complete();

        uint32_t output_len = 0;

        // 处理数据块 - 复用传统模式的函数
        int result = process_file_chunk_gcm_siv(session->mode, input_buffer, received_len,
                                               output_buffer, &output_len, session, key);

        if (result != 0) {
            DBG_PRINT("GCM-SIV processing failed for chunk %lu: result=%d\n",
                     chunk_count, result);
            printf("B64:\n");
            wait_for_tx_complete();
            printf("CHUNK_PROCESSED:%d->%d\n", received_len, 0);
            wait_for_tx_complete();

            // 解密失败立即退出
            if (session->mode == OP_DECRYPT) {
                DBG_PRINT("Decryption authentication failed in streaming mode\n");
                printf("ERROR:Authentication failed\n");
                wait_for_tx_complete();
                break;
            }
        } else {
            // 成功处理
            if (session->mode == OP_DECRYPT) {
                // 解密模式：发送解密后的数据
                send_encrypted_data_base64(output_buffer, output_len);
                wait_for_tx_complete();
            } else {
                // 加密模式：发送加密后的数据
                send_encrypted_data_base64(output_buffer, output_len);
                wait_for_tx_complete();
            }

            printf("CHUNK_PROCESSED:%d->%d\n", received_len, output_len);
            wait_for_tx_complete();
        }

        // 在流式模式下，发送处理统计
        printf("STREAM_STATS: chunks=%lu, bytes=%lu\n", chunk_count, total_received);
        wait_for_tx_complete();
    }

    // 流式处理完成
    printf("STREAM_COMPLETE\n");
    wait_for_tx_complete();
    printf("SUMMARY: received=%lu, processed=%lu, chunks=%lu\n",
           total_received, session->total_processed, chunk_count);
    wait_for_tx_complete();
}

// ==================== 流式文件处理 ====================

void new_stream_file_processing(void) {
    printf("NEW_STREAM_MODE\n");
    init_systick();

    // 等待操作选择
    printf("WAIT_OPERATION\n");
    clear_receive_buffer();

    // 读取操作模式
    uint8_t op_byte;
    if (read_exact_data(&op_byte, 1, 1000) != 1) {
        send_error("No operation received");
        return;
    }

    operation_mode_t mode;
    if (op_byte == 'e' || op_byte == 'E') {
        mode = OP_ENCRYPT;
        printf("OPERATION:ENCRYPT\n");
    } else if (op_byte == 'd' || op_byte == 'D') {
        mode = OP_DECRYPT;
        printf("OPERATION:DECRYPT\n");
    } else {
        send_error("Invalid operation");
        return;
    }

    // 发送确认
    send_ack();

    // 接收密钥 (16字节)
    printf("WAIT_KEY\n");
    clear_receive_buffer();

    uint8_t key[16];
    uint32_t key_bytes_received = read_exact_data(key, 16, 5000);
    if (key_bytes_received != 16) {
        // 使用默认密钥
        uint8_t default_key[16] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
        memcpy(key, default_key, 16);
        printf("Using default key\n");
    } else {
        printf("Custom key received\n");
    }

    // 发送密钥确认
    send_ack();

    // 接收基础Nonce (16字节)
    printf("WAIT_NONCE\n");
    clear_receive_buffer();

    uint8_t base_nonce[16];
    uint32_t nonce_bytes_received = read_exact_data(base_nonce, 16, 5000);
    if (nonce_bytes_received != 16) {
        // 使用默认Nonce
        uint8_t default_nonce[16] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
        memcpy(base_nonce, default_nonce, 16);
        printf("Using default nonce\n");
    } else {
        printf("Custom nonce received\n");
    }

    // 发送Nonce确认
    send_ack();

    // 读取文件大小或流式模式标记
    printf("WAIT_SIZE\n");
    clear_receive_buffer();

    uint8_t size_buffer[4];
    uint32_t size_bytes_received = read_exact_data(size_buffer, 4, 5000);

    if (size_bytes_received != 4) {
        DBG_PRINT("File size receive failed: %lu/4\n", size_bytes_received);
        send_error("File size receive failed");
        return;
    }

    // 解析文件大小 (大端序)
    uint32_t file_size = (size_buffer[0] << 24) | (size_buffer[1] << 16) |
                        (size_buffer[2] << 8) | size_buffer[3];

    // 初始化GCM-SIV会话
    gcm_siv_session_t session = {0};
    session.mode = mode;
    session.total_file_size = file_size;
    session.total_processed = 0;
    session.chunk_index = 0;
    session.is_last_chunk = 0;
    session.is_streaming = 0;
    session.streaming_active = 0;

    memcpy(session.base_nonce, base_nonce, 16);

    // 检查是否为流式模式标记
    if (file_size == STREAMING_MODE_MARKER) {
        printf("STREAMING_MODE\n");
        session.is_streaming = 1;
        session.streaming_active = 1;
        session.total_file_size = 0; // 流式模式下总大小为未知

        // 发送确认
        send_ack();

        // 关键：给硬件一些预热时间（模拟传统模式的自然延迟）
		DBG_PRINT("Giving hardware time to warm up for streaming mode...\n");
		for (volatile uint32_t i = 0; i < 200000; i++); // ~200ms延迟

        // 进入流式处理
        process_streaming_data(&session, key);
        return;
    } else {
        // 传统模式，检查文件大小限制
        printf("FILE_SIZE:%lu\n", file_size);

        if (file_size == 0 || file_size > MAX_FILE_SIZE) {
            send_error("Invalid file size");
            return;
        }

        // 发送确认
        send_ack();

        printf("READY_FOR_DATA\n");

        // 传统模式处理
        process_traditional_data(&session, key);
        return;
    }
}

int main(void) {
    RCC_Configuration();
    GPIO_Configuration();

    USART_InitStructure.BaudRate            = 115200;
    USART_InitStructure.WordLength          = USART_WL_8B;
    USART_InitStructure.StopBits            = USART_STPB_1;
    USART_InitStructure.Parity              = USART_PE_NO;
    USART_InitStructure.HardwareFlowControl = USART_HFCTRL_NONE;
    USART_InitStructure.Mode                = USART_MODE_RX | USART_MODE_TX;

    USART_Init(USARTx, &USART_InitStructure);
    USART_Enable(USARTx, ENABLE);

    init_systick();

    while (1) {
        printf("Initializing...\n");
        clear_receive_buffer();

        printf("MCU Startup Successful!\n");
        printf("READY\n");

        int choice = _get_char();
        printf("MODE:%c\n", choice);

        switch (choice) {
            case 'n':
            case 'N':
                printf("Starting New Stream Processing...\n");
                new_stream_file_processing();
                break;
            case 'r':
            case 'R':
                printf("Software reset...\n");
                break;
            default:
                printf("Invalid choice\n");
                break;
        }

        printf("Operation completed. Waiting for next command...\n");
        clear_receive_buffer();
    }
}
