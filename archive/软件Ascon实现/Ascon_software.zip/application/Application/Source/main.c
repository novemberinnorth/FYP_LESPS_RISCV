#include <main.h>
#include "bsp.h"
#include "api.h"
#include "crypto_aead.h"
#include <string.h>
#include <stdio.h>

// 宏定义
#define CHUNK_SIZE 1024
#define AES_BLOCK_SIZE 16
#define GCM_SIV_TAG_SIZE 16
#define B64_BUFFER_SIZE 2100
#define MAX_AAD_SIZE 1024

// 调试级别控制
#define DEBUG_LEVEL 1

#if DEBUG_LEVEL >= 1
#define DBG_PRINT(...) printf(__VA_ARGS__)
#else
#define DBG_PRINT(...)
#endif

#if DEBUG_LEVEL >= 2
#define DBG_VERBOSE(...) printf(__VA_ARGS__)
#else
#define DBG_VERBOSE(...)
#endif

// 操作模式
typedef enum {
    OP_ENCRYPT,
    OP_DECRYPT
} operation_mode_t;

// GCM-SIV会话状态（保持与AES-GCM-SIV版本相同）
typedef struct {
    operation_mode_t mode;
    uint8_t base_nonce[16];     // 基础Nonce
    uint32_t total_processed;
    uint32_t chunk_index;       // 块索引
    uint8_t streaming_active;   // 流式模式是否激活
    uint8_t aad[1024];          // AAD 缓冲区
    uint32_t aad_len;           // AAD 长度
} gcm_siv_session_t;

USART_InitType USART_InitStructure;

// 全局缓冲区
static uint8_t input_buffer[CHUNK_SIZE + 64];
static uint8_t output_buffer[CHUNK_SIZE + 80];  // Ascon可能需要更多空间

void RCC_Configuration(void) {
    GPIO_APBxClkCmd(USARTx_GPIO_CLK | RCC_APB2_PERIPH_AFIO, ENABLE);
    USART_APBxClkCmd(USARTx_CLK, ENABLE);
}

void GPIO_Configuration(void) {
    GPIO_InitType GPIO_InitStructure;
    GPIO_ConfigPinRemap(GPIO_RMP3_UART4, ENABLE);

    GPIO_InitStructure.Pin        = USARTx_TxPin;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_Init(USARTx_GPIO, &GPIO_InitStructure);

    GPIO_InitStructure.Pin       = USARTx_RxPin;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(USARTx_GPIO, &GPIO_InitStructure);
}

int _put_char(int ch) {
    USART_SendData(USARTx, (uint8_t)ch);
    while (USART_GetFlagStatus(USARTx, USART_FLAG_TXDE) == RESET);
    return ch;
}

int _get_char(void) {
    uint32_t timeout = 5000000;
    while (USART_GetFlagStatus(USARTx, USART_FLAG_RXDNE) == RESET) {
        timeout--;
        if (timeout == 0) return -1;
    }
    int ch = (int)USART_ReceiveData(USARTx);
    return ch;
}

// 系统滴答计时器
volatile uint32_t system_tick = 0;

void SysTick_Handler(void) {
    system_tick++;
}

uint32_t get_current_time(void) {
    return system_tick * 1000;
}

void init_systick(void) {
    SysTick_Config(SystemCoreClock / 1000);
}

void send_ack(void) {
    printf("ACK\n");
}

void send_error(const char* message) {
    printf("ERROR:%s\n", message);
}

void clear_receive_buffer(void) {
    DBG_VERBOSE("Clearing receive buffer...\n");
    uint32_t cleared_count = 0;
    while (USART_GetFlagStatus(USARTx, USART_FLAG_RXDNE) != RESET) {
        USART_ReceiveData(USARTx);
        cleared_count++;
    }
    DBG_VERBOSE("Cleared %lu bytes\n", cleared_count);
}

uint32_t read_exact_data(uint8_t *data, uint32_t exact_len, uint32_t timeout_ms) {
    uint32_t bytes_read = 0;
    uint32_t timeout = timeout_ms * 1000;
    uint32_t last_receive_time = get_current_time();
    uint32_t start_time = get_current_time();

    DBG_VERBOSE("Reading %d bytes\n", exact_len);

    while (bytes_read < exact_len) {
        if (USART_GetFlagStatus(USARTx, USART_FLAG_RXDNE) != RESET) {
            data[bytes_read] = USART_ReceiveData(USARTx);
            bytes_read++;
            last_receive_time = get_current_time();

            if (bytes_read % 100 == 0) {
                DBG_VERBOSE("Received %d/%d\n", bytes_read, exact_len);
            }
        } else {
            uint32_t current_time = get_current_time();
            if (current_time - last_receive_time > 500000) {
                DBG_PRINT("No data timeout: %d/%d\n", bytes_read, exact_len);
                break;
            }
            if (current_time - start_time > timeout) {
                DBG_PRINT("Overall timeout: %d/%d\n", bytes_read, exact_len);
                break;
            }
        }
    }

    DBG_VERBOSE("Read complete: %d/%d\n", bytes_read, exact_len);
    return bytes_read;
}

// 等待发送完成
void wait_for_tx_complete(void) {
    while (USART_GetFlagStatus(USARTx, USART_FLAG_TXDE) == RESET) {
        for(volatile int i = 0; i < 100; i++);
    }
}

// Base64发送函数（保持与AES-GCM-SIV版本相同）
void send_encrypted_data_base64(uint8_t *data, uint32_t len) {
    const char base64_chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    uint32_t b64_len = 4 * ((len + 2) / 3);

    static char b64_buffer[B64_BUFFER_SIZE];
    static uint8_t buffer_lock = 0;

    while (buffer_lock) {
        for(volatile int i = 0; i < 1000; i++);
    }

    buffer_lock = 1;

    if (len == 0 || len > (CHUNK_SIZE + 32)) {
        printf("ERROR: Invalid data length for Base64: %lu\n", len);
        buffer_lock = 0;
        return;
    }

    if (b64_len >= B64_BUFFER_SIZE) {
        printf("ERROR: Base64 buffer too small: needed %lu, have %lu\n",
               b64_len, B64_BUFFER_SIZE);
        buffer_lock = 0;
        return;
    }

    DBG_VERBOSE("Base64 encoding: input_len=%lu, b64_len=%lu\n", len, b64_len);

    int i, j;
    uint32_t triple;

    for (i = 0, j = 0; i < len; i += 3, j += 4) {
        triple = (data[i] << 16);
        if (i + 1 < len) triple |= (data[i + 1] << 8);
        if (i + 2 < len) triple |= data[i + 2];

        b64_buffer[j]   = base64_chars[(triple >> 18) & 0x3F];
        b64_buffer[j+1] = base64_chars[(triple >> 12) & 0x3F];
        b64_buffer[j+2] = (i + 1 < len) ? base64_chars[(triple >> 6) & 0x3F] : '=';
        b64_buffer[j+3] = (i + 2 < len) ? base64_chars[triple & 0x3F] : '=';
    }
    b64_buffer[j] = '\0';

    if (strlen(b64_buffer) != b64_len) {
        printf("ERROR: Base64 length mismatch: expected %lu, got %lu\n",
               b64_len, strlen(b64_buffer));
        buffer_lock = 0;
        return;
    }

    printf("B64:%s\n", b64_buffer);
    wait_for_tx_complete();

    for(volatile int i = 0; i < 5000; i++);

    DBG_VERBOSE("Base64 sent: %lu chars\n", strlen(b64_buffer));

    buffer_lock = 0;
}

// ==================== Ascon适配GCM-SIV协议 ====================

/**
 * @brief 更新Nonce（基于块索引的确定性策略）- 适配Ascon
 * Ascon需要16字节Nonce，我们使用基础Nonce的前12字节和块索引后4字节
 */
void update_nonce_ascon(uint8_t *nonce, const uint8_t *base_nonce, uint32_t chunk_index) {
    // 使用基础Nonce的前12字节
    memcpy(nonce, base_nonce, 12);

    // 后4字节存储块索引（大端序）
    nonce[12] = (chunk_index >> 24) & 0xFF;
    nonce[13] = (chunk_index >> 16) & 0xFF;
    nonce[14] = (chunk_index >> 8) & 0xFF;
    nonce[15] = chunk_index & 0xFF;

    DBG_VERBOSE("Ascon Nonce for chunk %lu: ", chunk_index);
    for(int i=0; i<16; i++) DBG_VERBOSE("%02x", nonce[i]);
    DBG_VERBOSE("\n");
}

/**
 * @brief 单个块的Ascon加密（适配GCM-SIV协议格式）
 * 模拟GCM-SIV格式：密文+标签
 */
int ascon_encrypt_single_chunk(uint8_t *ciphertext, uint8_t tag[16],
                              uint8_t key[16], uint8_t nonce[16],
                              uint8_t *plaintext, uint32_t plaintext_len,
                              uint8_t *aad, uint32_t aad_len) {

    unsigned long long clen;
    uint8_t temp_buffer[CHUNK_SIZE + 80];  // 临时缓冲区

    DBG_VERBOSE("Ascon encrypt: plaintext_len=%u, aad_len=%u\n", plaintext_len, aad_len);

    // 调用Ascon加密
    int result = crypto_aead_encrypt(temp_buffer, &clen,
                                    plaintext, plaintext_len,
                                    aad, aad_len,  // 使用AAD
                                    NULL, nonce, key);

    if (result != 0) {
        DBG_PRINT("Ascon encryption failed: result=%d\n", result);
        return -1;
    }

    // Ascon的密文格式：密文+标签
    // 对于流式处理，我们直接使用整个输出
    memcpy(ciphertext, temp_buffer, clen);

    // 提取标签（最后16字节）
    if (tag != NULL && clen >= 16) {
        memcpy(tag, temp_buffer + clen - 16, 16);
    }

    DBG_VERBOSE("Ascon encrypt success: clen=%llu\n", clen);
    return 0;
}

/**
 * @brief 单个块的Ascon解密（适配GCM-SIV协议格式）
 */
int ascon_decrypt_single_chunk(uint8_t *plaintext,
                              uint8_t key[16], uint8_t nonce[16],
                              uint8_t *ciphertext, uint32_t ciphertext_len,
                              uint8_t *expected_tag,
                              uint8_t *aad, uint32_t aad_len) {

    unsigned long long mlen;

    DBG_VERBOSE("Ascon decrypt: ciphertext_len=%u, aad_len=%u\n", ciphertext_len, aad_len);

    // 对于Ascon，密文已经包含了标签
    // 所以ciphertext_len应该是密文+标签的长度

    // 调用Ascon解密
    int result = crypto_aead_decrypt(plaintext, &mlen,
                                    NULL,  // nsec
                                    ciphertext, ciphertext_len,
                                    aad, aad_len,  // 使用AAD
                                    nonce, key);

    if (result != 0) {
        DBG_PRINT("Ascon decryption failed - authentication failed\n");
        DBG_PRINT("  Nonce: ");
        for(int i=0; i<16; i++) DBG_PRINT("%02x", nonce[i]);
        DBG_PRINT("\n");
        return -1;
    }

    DBG_VERBOSE("Ascon decrypt success: mlen=%llu\n", mlen);
    return 0;
}

/**
 * @brief 处理文件块加解密 - Ascon适配GCM-SIV协议版本
 */
int process_file_chunk_ascon_gcm_siv(operation_mode_t mode, uint8_t *input_data, uint32_t input_len,
                                    uint8_t *output_data, uint32_t *output_len,
                                    gcm_siv_session_t *session, uint8_t *key) {

    DBG_PRINT("Processing chunk %lu: mode=%s, input_len=%u\n",
              session->chunk_index, mode == OP_ENCRYPT ? "encrypt" : "decrypt",
              input_len);

    uint8_t nonce[16];
    uint8_t tag[16];

    // 生成块Nonce（适配Ascon）
    update_nonce_ascon(nonce, session->base_nonce, session->chunk_index);

    DBG_VERBOSE("Ascon Processing: mode=%s, len=%d, chunk_index=%lu\n",
                mode == OP_ENCRYPT ? "encrypt" : "decrypt", input_len, session->chunk_index);

    if (mode == OP_ENCRYPT) {
        // 加密这个块（包含AAD）
        int result = ascon_encrypt_single_chunk(output_data, tag, key, nonce,
                                                input_data, input_len,
                                                session->aad, session->aad_len);
        if (result != 0) {
            DBG_PRINT("Ascon encryption failed for chunk %lu\n", session->chunk_index);
            return -1;
        }

        // 计算实际输出长度（Ascon加密后长度）
        unsigned long long clen;
        crypto_aead_encrypt(output_data, &clen,
                           input_data, input_len,
                           session->aad, session->aad_len,
                           NULL, nonce, key);

        *output_len = clen;

    } else {
        // 解密模式：分离密文和标签（对于Ascon，标签已包含在密文中）
        if (input_len < CRYPTO_ABYTES) {
            DBG_PRINT("Invalid input length for decryption: %d\n", input_len);
            return -1;
        }

        // Ascon解密：整个输入都是密文（包含标签）
        unsigned long long mlen;
        int result = crypto_aead_decrypt(output_data, &mlen,
                                        NULL,
                                        input_data, input_len,
                                        session->aad, session->aad_len,
                                        nonce, key);

        if (result != 0) {
            DBG_PRINT("Ascon decryption failed for chunk %lu\n", session->chunk_index);
            return -1;
        }

        *output_len = mlen;
    }

    // 递增块索引
    session->chunk_index++;
    session->total_processed += input_len;

    DBG_VERBOSE("Chunk processed: index=%lu, total=%lu bytes\n",
                session->chunk_index, session->total_processed);

    return 0;
}

// 流式模式数据处理函数 - 适配GCM-SIV协议
void process_streaming_data(gcm_siv_session_t *session, uint8_t *key) {
    uint32_t total_received = 0;
    uint32_t chunk_count = 0;
    uint8_t streaming_ended = 0;

    printf("READY_FOR_DATA\n");
    wait_for_tx_complete();

    // 流式模式处理循环（与AES-GCM-SIV版本相同）
    while (!streaming_ended) {
        chunk_count++;
        session->chunk_index = chunk_count - 1;

        // 根据操作模式调整请求的块大小
        uint32_t requested_size;
        if (session->mode == OP_DECRYPT) {
            // 解密模式：Ascon密文包含标签，所以块更大
            requested_size = CHUNK_SIZE + CRYPTO_ABYTES;
            DBG_VERBOSE("Decrypt mode: requesting %lu bytes (CHUNK_SIZE + %d)\n",
                       requested_size, CRYPTO_ABYTES);
        } else {
            // 加密模式：只需要接收明文
            requested_size = CHUNK_SIZE;
            DBG_VERBOSE("Encrypt mode: requesting %lu bytes\n", requested_size);
        }

        printf("WAIT_CHUNK:%d\n", requested_size);
        wait_for_tx_complete();

        // 接收数据块（包含4字节头部）
        uint8_t chunk_header[4];
        uint32_t header_received = read_exact_data(chunk_header, 4, 10000);

        if (header_received != 4) {
            DBG_PRINT("Failed to receive chunk header\n");
            printf("ERROR:Chunk header receive failed\n");
            break;
        }

        // 解析块大小（大端序）
        uint32_t chunk_size = (chunk_header[0] << 24) | (chunk_header[1] << 16) |
                             (chunk_header[2] << 8) | chunk_header[3];

        // 检查是否为结束标记（块大小为0）
        if (chunk_size == 0) {
            printf("END_OF_STREAM\n");
            wait_for_tx_complete();
            streaming_ended = 1;
            session->streaming_active = 0;
            break;
        }

        // 检查块大小是否合理
        uint32_t max_expected_size = (session->mode == OP_DECRYPT) ?
                                     (CHUNK_SIZE + CRYPTO_ABYTES + 64) : (CHUNK_SIZE + 64);

        if (chunk_size > max_expected_size) {
            DBG_PRINT("Invalid chunk size: %lu (max expected: %lu)\n", chunk_size, max_expected_size);
            printf("ERROR:Invalid chunk size\n");
            break;
        }

        // 接收实际数据
        uint32_t received_len = read_exact_data(input_buffer, chunk_size, 10000);

        if (received_len != chunk_size) {
            DBG_PRINT("Chunk receive failed: expected %lu, got %lu\n",
                     chunk_size, received_len);
            printf("ERROR:Chunk receive failed\n");
            break;
        }

        total_received += received_len;
        printf("CHUNK_RECEIVED:%d\n", received_len);
        wait_for_tx_complete();

        uint32_t output_len = 0;

        // 处理数据块 - 使用Ascon实现
        int result = process_file_chunk_ascon_gcm_siv(session->mode, input_buffer, received_len,
                                                     output_buffer, &output_len, session, key);

        if (result != 0) {
            DBG_PRINT("Ascon processing failed for chunk %lu: result=%d\n",
                     chunk_count, result);
            printf("B64:\n");
            wait_for_tx_complete();
            printf("CHUNK_PROCESSED:%d->%d\n", received_len, 0);
            wait_for_tx_complete();

            // 解密失败立即退出
            if (session->mode == OP_DECRYPT) {
                DBG_PRINT("Decryption authentication failed in streaming mode\n");
                printf("ERROR:Authentication failed\n");
                wait_for_tx_complete();
                break;
            }
        } else {
            // 成功处理
            if (session->mode == OP_DECRYPT) {
                // 解密模式：发送解密后的数据
                send_encrypted_data_base64(output_buffer, output_len);
                wait_for_tx_complete();
            } else {
                // 加密模式：发送加密后的数据
                send_encrypted_data_base64(output_buffer, output_len);
                wait_for_tx_complete();
            }

            printf("CHUNK_PROCESSED:%lu->%lu\n", (unsigned long)received_len, (unsigned long)output_len);
            wait_for_tx_complete();
        }

        // 在流式模式下，发送处理统计
        printf("STREAM_STATS: chunks=%lu, bytes=%lu\n",
               (unsigned long)chunk_count, (unsigned long)total_received);
        wait_for_tx_complete();

        // 额外延迟
        for(volatile int i = 0; i < 5000; i++);
    }

    // 流式处理完成
    printf("STREAM_COMPLETE\n");
    wait_for_tx_complete();
    printf("SUMMARY: received=%lu, processed=%lu, chunks=%lu\n",
           total_received, session->total_processed, chunk_count);
    wait_for_tx_complete();
}

// ==================== 流式文件处理（适配GCM-SIV协议） ====================

void new_stream_file_processing(void) {
    printf("NEW_STREAM_MODE\n");
    init_systick();

    // 等待操作选择
    printf("WAIT_OPERATION\n");
    clear_receive_buffer();

    // 读取操作模式
    uint8_t op_byte;
    if (read_exact_data(&op_byte, 1, 1000) != 1) {
        send_error("No operation received");
        return;
    }

    operation_mode_t mode;
    if (op_byte == 'e' || op_byte == 'E') {
        mode = OP_ENCRYPT;
        printf("OPERATION:ENCRYPT\n");
    } else if (op_byte == 'd' || op_byte == 'D') {
        mode = OP_DECRYPT;
        printf("OPERATION:DECRYPT\n");
    } else {
        send_error("Invalid operation");
        return;
    }

    // 发送确认
    send_ack();

    // 接收密钥 (16字节) - Ascon使用16字节密钥
    printf("WAIT_KEY\n");
    clear_receive_buffer();

    uint8_t key[CRYPTO_KEYBYTES];
    uint32_t key_bytes_received = read_exact_data(key, CRYPTO_KEYBYTES, 5000);
    if (key_bytes_received != CRYPTO_KEYBYTES) {
        // 使用默认密钥
        uint8_t default_key[CRYPTO_KEYBYTES] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
        memcpy(key, default_key, CRYPTO_KEYBYTES);
        printf("Using default key\n");
    } else {
        printf("Custom key received\n");
    }

    // 发送密钥确认
    send_ack();

    // 接收基础Nonce (16字节) - Ascon需要16字节Nonce
    printf("WAIT_NONCE\n");
    clear_receive_buffer();

    uint8_t base_nonce[CRYPTO_NPUBBYTES];
    uint32_t nonce_bytes_received = read_exact_data(base_nonce, CRYPTO_NPUBBYTES, 5000);
    if (nonce_bytes_received != CRYPTO_NPUBBYTES) {
        // 使用默认Nonce
        uint8_t default_nonce[CRYPTO_NPUBBYTES] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
        memcpy(base_nonce, default_nonce, CRYPTO_NPUBBYTES);
        printf("Using default nonce\n");
    } else {
        printf("Custom nonce received\n");
    }

    // 发送Nonce确认
    send_ack();

    // 接收AAD长度（与AES-GCM-SIV协议相同）
    printf("WAIT_AAD_LEN\n");
    clear_receive_buffer();

    uint8_t aad_len_buffer[4];
    uint32_t aad_len_bytes_received = read_exact_data(aad_len_buffer, 4, 5000);
    uint32_t aad_len = 0;
    uint8_t aad_buffer[MAX_AAD_SIZE] = {0};

    if (aad_len_bytes_received == 4) {
        // 解析AAD长度（大端序）
        aad_len = (aad_len_buffer[0] << 24) | (aad_len_buffer[1] << 16) |
                  (aad_len_buffer[2] << 8) | aad_len_buffer[3];

        printf("AAD length: %lu bytes\n", (unsigned long)aad_len);

        // 发送确认
        send_ack();

        // 接收AAD数据（如果有）
        if (aad_len > 0) {
            printf("WAIT_AAD_DATA\n");
            clear_receive_buffer();

            // 确保AAD不超过缓冲区大小
            if (aad_len > sizeof(aad_buffer)) {
                printf("AAD too large, truncating to %lu bytes\n", (unsigned long)sizeof(aad_buffer));
                aad_len = sizeof(aad_buffer);
            }

            uint32_t aad_bytes_received = read_exact_data(aad_buffer, aad_len, 5000);

            if (aad_bytes_received == aad_len) {
                printf("AAD received: %lu bytes\n", (unsigned long)aad_len);
            } else {
                printf("AAD receive failed: %lu/%lu bytes\n",
                       (unsigned long)aad_bytes_received, (unsigned long)aad_len);
                aad_len = 0;
                memset(aad_buffer, 0, sizeof(aad_buffer));
            }

            // 发送确认
            send_ack();
        }
    } else {
        // 如果没有收到AAD长度，跳过AAD
        printf("No AAD length received, skipping AAD\n");
        send_ack();
    }

    // 初始化GCM-SIV会话（适配Ascon）
    gcm_siv_session_t session = {0};
    session.mode = mode;
    session.total_processed = 0;
    session.chunk_index = 0;
    session.streaming_active = 1;
    session.aad_len = aad_len;

    // 复制AAD数据到会话（如果有）
    if (aad_len > 0 && aad_len <= sizeof(session.aad)) {
        memcpy(session.aad, aad_buffer, aad_len);
    }

    memcpy(session.base_nonce, base_nonce, CRYPTO_NPUBBYTES);

    // 关键：给硬件一些预热时间
    DBG_PRINT("Giving hardware time to warm up...\n");
    for (volatile uint32_t i = 0; i < 200000; i++);

    // 进入流式处理（与AES-GCM-SIV版本相同）
    process_streaming_data(&session, key);
}

int main(void) {
    RCC_Configuration();
    GPIO_Configuration();

    USART_InitStructure.BaudRate            = 115200;
    USART_InitStructure.WordLength          = USART_WL_8B;
    USART_InitStructure.StopBits            = USART_STPB_1;
    USART_InitStructure.Parity              = USART_PE_NO;
    USART_InitStructure.HardwareFlowControl = USART_HFCTRL_NONE;
    USART_InitStructure.Mode                = USART_MODE_RX | USART_MODE_TX;

    USART_Init(USARTx, &USART_InitStructure);
    USART_Enable(USARTx, ENABLE);

    init_systick();

    while (1) {
        printf("Initializing...\n");
        clear_receive_buffer();

        printf("MCU Startup Successful!\n");
        printf("READY\n");

        int choice = _get_char();
        printf("MODE:%c\n", choice);

        switch (choice) {
            case 'n':
            case 'N':
                printf("Starting New Stream Processing...\n");
                new_stream_file_processing();
                break;
            case 'r':
            case 'R':
                printf("Software reset...\n");
                break;
            default:
                printf("Invalid choice\n");
                break;
        }

        printf("Operation completed. Waiting for next command...\n");
        clear_receive_buffer();
    }
}
