#ifndef _AES_H_
#define _AES_H_

#include <stdint.h>
#include <stddef.h>

// 只启用CBC模式
#define CBC 1
#define ECB 0  // 禁用ECB
#define CTR 0  // 禁用CTR

#define AES128 1
// 明确禁用AES192和AES256
#define AES192 0
#define AES256 0

#define AES_BLOCKLEN 16
#define AES_KEYLEN 16
#define AES_keyExpSize 176

struct AES_ctx
{
  uint8_t RoundKey[AES_keyExpSize];
  uint8_t Iv[AES_BLOCKLEN];  // 由于CBC始终启用，可以移出条件编译
};

void AES_init_ctx(struct AES_ctx* ctx, const uint8_t* key);
void AES_init_ctx_iv(struct AES_ctx* ctx, const uint8_t* key, const uint8_t* iv);
void AES_ctx_set_iv(struct AES_ctx* ctx, const uint8_t* iv);

// 只保留CBC模式函数
void AES_CBC_encrypt_buffer(struct AES_ctx* ctx, uint8_t* buf, size_t length);
void AES_CBC_decrypt_buffer(struct AES_ctx* ctx, uint8_t* buf, size_t length);

#endif
